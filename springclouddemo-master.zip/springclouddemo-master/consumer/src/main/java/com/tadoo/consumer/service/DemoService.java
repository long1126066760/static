package com.tadoo.consumer.service;

public interface DemoService {
    String consumerDemo();
}
